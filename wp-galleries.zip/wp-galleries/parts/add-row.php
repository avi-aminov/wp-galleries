<div id="add_field_row">
    <input class="button" type="button" value="<?php echo __('Add Image', 'wp-galleries'); ?>" onclick="Galleries.addFieldRow();" />
</div>